﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenTimeTracker
{
    public class TrackerConfig
    {
        public int IdleThresholdMinutes { get; set; }
        public int PollingIntervalSeconds { get; set; }
        public string? LogDirectory { get; set; }
        public string? ReportDirectory { get; set; }
        public bool EnableEncryption { get; set; }
        public bool EnableEmailSummary { get; set; }
        public TimeSpan EmailSummaryTime { get; set; }
        
        public string ExcelReportDirectory { get; set; } = "Reports";
        public bool EnableExcelReport { get; set; } = true;
    }

}
