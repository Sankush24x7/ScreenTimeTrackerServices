﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using ScreenTimeTracker;
using Microsoft.Extensions.Hosting.WindowsServices;

Host.CreateDefaultBuilder(args)
    .UseWindowsService() // ✅ Works here
    .ConfigureServices((context, services) =>
    {
        services.Configure<TrackerConfig>(context.Configuration.GetSection("TrackerConfig"));
        services.Configure<EmailSettings>(context.Configuration.GetSection("EmailSettings"));
        services.AddHostedService<Worker>();
    })
    .Build()
    .Run();






//Publish the service
//In Visual Studio:

//Right - click project → Publish

//Target folder: C:\ScreenTimeService
//sc create ScreenTimeTrackerService binPath= "C:\ScreenTimeService\ScreenTimeTracker.Service.exe"
//sc start ScreenTimeTrackerService


//To auto-start on boot:
//    sc config ScreenTimeTrackerService start= auto



//sc create ScreenTimeTrackerService binPath= "C:\ScreenTimeService\ScreenTimeTrackerServices.exe"
//sc config ScreenTimeTrackerService start= auto
//sc start ScreenTimeTrackerService
//sc delete ScreenTimeTrackerService

