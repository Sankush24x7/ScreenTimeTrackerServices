﻿using Microsoft.Extensions.Options;
using ScreenTimeTracker;
using ScreenTimeTracker.Reporting;
using ScreenTimeTracker.Models;
using System.Text.Json;

public class Worker : BackgroundService
{
    private readonly TrackerConfig _config;
    private readonly EmailSettings _email;

    private DateTime currentDate = DateTime.Today;
    private string logFile = string.Empty;

    public Worker(IOptions<TrackerConfig> config, IOptions<EmailSettings> email)
    {
        _config = config.Value;
        _email = email.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        string logDir = Path.Combine(AppContext.BaseDirectory, _config.LogDirectory);
        string reportDir = Path.Combine(AppContext.BaseDirectory, _config.ReportDirectory);
        Directory.CreateDirectory(logDir);
        Directory.CreateDirectory(reportDir);


        logFile = Path.Combine(logDir, $"{currentDate:yyyy-MM-dd}.json");
        if (!File.Exists(logFile))
            File.WriteAllBytes(logFile, Encryptor.Encrypt("[]"));

        // ✅ Generate Excel report once per day
        string excelPath = Path.Combine(reportDir, $"ConsolidatedReport_{DateTime.Now:yyyyMMdd}.xlsx");

        if (_config.EnableExcelReport)
        {
            DailySummaryResult summary = DailySummary.GenerateSummary(currentDate);
            string summaryPath = Path.Combine(reportDir, $"summary_{currentDate:yyyyMMdd}.json");
            File.WriteAllText(summaryPath, JsonSerializer.Serialize(summary));

            // Load all daily summaries from the report directory
            List<EDailySummaryResult> summaries = SummaryLoader.LoadAllSummaries(reportDir);

            // ✅ Optional: log how many summaries were found
            Console.WriteLine($"📊 Loaded {summaries.Count} summaries for Excel report");

            // ✅ Generate Excel report
            excelPath = ExcelReportBuilder.BuildConsolidatedReport(summaries, reportDir);

            // ✅ Log result
            if (File.Exists(excelPath))
            {
                Console.WriteLine($"✅ Excel report generated: {excelPath}");
            }
            else
            {
                Console.WriteLine($"❌ Excel report not found at: {excelPath}");
            }
        }

        if (!File.Exists(excelPath))
        {
            File.WriteAllText(excelPath, "Excel report was skipped today.");
        }

        bool _summarySentToday = false;

        while (!stoppingToken.IsCancellationRequested)
        {
            DateTime now = DateTime.Now;

            // ✅ Email summary logic
            if (_config.EnableEmailSummary && now.TimeOfDay >= _config.EmailSummaryTime && !_summarySentToday)
            {
                string htmlPath = Path.Combine(reportDir, $"report_{currentDate:yyyyMMdd}.html");
                if (File.Exists(htmlPath) && File.Exists(excelPath))
                {
                    EmailSender.SendReport(_email, htmlPath, excelPath, currentDate);
                    _summarySentToday = true;
                    Console.WriteLine($"📧 Email summary sent for {currentDate:yyyy-MM-dd}");
                }
                Console.WriteLine($"📊 Excel report {(_config.EnableExcelReport ? "generated" : "skipped")} for {DateTime.Now:yyyy-MM-dd}");
            }

            // ✅ Daily rollover
            if (now.Date > currentDate)
            {
                string previousLogFile = Path.Combine(logDir, $"{currentDate:yyyy-MM-dd}.json");
                if (File.Exists(previousLogFile))
                {
                    byte[] prevEncrypted = File.ReadAllBytes(previousLogFile);
                    string prevDecrypted = Encryptor.Decrypt(prevEncrypted);
                    List<ActivityLog> prevLogs = JsonSerializer.Deserialize<List<ActivityLog>>(prevDecrypted) ?? new();
                    DailySummaryResult prevSummary = DailySummary.GenerateSummary(currentDate);

                    // Save summary JSON
                    string summaryPath = Path.Combine(reportDir, $"summary_{currentDate:yyyyMMdd}.json");
                    File.WriteAllText(summaryPath, JsonSerializer.Serialize(prevSummary));

                    // Generate HTML report with retry
                    try
                    {
                        HtmlBuilder.GenerateReport(prevSummary, prevLogs);
                        
                    }
                    catch (IOException ex)
                    {
                        File.AppendAllText("error_log.txt", $"{DateTime.Now}: HTML write failed → {ex.Message}\n");
                    }
                }

                currentDate = now.Date;
                logFile = Path.Combine(logDir, $"{currentDate:yyyy-MM-dd}.json");
                File.WriteAllBytes(logFile, Encryptor.Encrypt("[]"));
                _summarySentToday = false;
            }

            // ✅ Capture snapshot
            string activeApp = AppLogger.GetActiveProcessName();
            string windowTitle = AppLogger.GetActiveWindowTitle();
            TimeSpan idleTime = IdleDetector.GetIdleTime();
            bool isIdle = idleTime > TimeSpan.FromMinutes(_config.IdleThresholdMinutes);

            ActivityLog logEntry = new ActivityLog
            {
                Timestamp = now,
                Status = isIdle ? "Idle" : "Active",
                AppName = activeApp,
                WindowTitle = windowTitle,
                IdleDuration = idleTime
            };

            byte[] encrypted = File.ReadAllBytes(logFile);
            string decrypted = Encryptor.Decrypt(encrypted);
            if (string.IsNullOrWhiteSpace(decrypted)) decrypted = "[]";

            List<ActivityLog> logs;
            try
            {
                logs = JsonSerializer.Deserialize<List<ActivityLog>>(decrypted) ?? new();
            }
            catch
            {
                logs = new();
            }

            logs.Add(logEntry);
            string updatedJson = JsonSerializer.Serialize(logs);
            byte[] updatedEncrypted = Encryptor.Encrypt(updatedJson);
            File.WriteAllBytes(logFile, updatedEncrypted);

            // ✅ Generate summary + save + HTML
            DailySummaryResult summary = DailySummary.GenerateSummary(currentDate);

            string summaryPathToday = Path.Combine(reportDir, $"summary_{currentDate:yyyyMMdd}.json");
            File.WriteAllText(summaryPathToday, JsonSerializer.Serialize(summary));

            try
            {
                HtmlBuilder.GenerateReport(summary, logs);
            }
            catch (IOException ex)
            {
                File.AppendAllText("error_log.txt", $"{DateTime.Now}: HTML write failed → {ex.Message}\n");
            }

            await Task.Delay(_config.PollingIntervalSeconds * 1000, stoppingToken);
        }
    }
}
