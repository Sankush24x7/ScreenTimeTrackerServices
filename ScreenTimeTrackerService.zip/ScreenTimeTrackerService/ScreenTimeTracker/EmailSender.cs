﻿using System.Net;
using System.Net.Mail;

namespace ScreenTimeTracker
{
    public static class EmailSender
    {
        public static void SendReport(EmailSettings settings, string reportPath, string excelPath, DateTime date)
        {
            
            int maxRetries = 3;
            int delaySeconds = 10;
            string systemName = Environment.MachineName;
            string hostName = System.Net.Dns.GetHostName();

            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    using var client = new SmtpClient(settings.SmtpServer, settings.Port)
                    {
                        Credentials = new NetworkCredential(settings.Username, settings.Password),
                        EnableSsl = true
                    };
                    string htmlContent = File.ReadAllText(reportPath);
                    var message = new MailMessage(settings.Sender, settings.Recipient)
                    {
                        //Subject = $"Screen Time Report - {date:yyyy-MM-dd}",
                        Subject = $"Screen Time Report - {date:yyyy-MM-dd} | System: {systemName} | Host: {hostName}",

                        Body = $"Attached is the screen time report for {date:yyyy-MM-dd}." + "\n" + htmlContent,
                        //Body = htmlContent,
                        IsBodyHtml = true,
                    };

                    message.Attachments.Add(new Attachment(reportPath));
                    //message.Attachments.Add(new Attachment(excelPath));
                    client.Send(message);

                    LogEmailStatus(reportPath, date, true, attempt);
                    return;
                }
                catch (Exception ex)
                {
                    LogEmailStatus(reportPath, date, false, attempt, ex.Message);
                    Thread.Sleep(delaySeconds * 1000);
                }
            }
        }

        private static void LogEmailStatus(string path, DateTime date, bool success, int attempt, string? error = null)
        {
            string logPath = Path.Combine(Path.GetDirectoryName(path)!, "email_log.txt");
            string status = success ? "✅ Sent" : $"❌ Failed (Attempt {attempt})";
            string line = $"{DateTime.Now:HH:mm:ss} {status} for {date:yyyy-MM-dd} → {Path.GetFileName(path)}";

            if (!success && error != null)
                line += $" | Error: {error}";

            File.AppendAllText(logPath, line + Environment.NewLine);
        }
    }

}
