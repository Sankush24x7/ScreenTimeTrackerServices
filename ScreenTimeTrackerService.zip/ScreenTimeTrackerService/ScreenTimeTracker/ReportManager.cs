﻿using ScreenTimeTracker.Models;
using System.Text.Json;
using ScreenTimeTracker.Reporting;
namespace ScreenTimeTracker;

public static class ReportManager
{
    public static void SaveEncryptedLog(string path, List<ActivityLog> logs)
    {
        string json = JsonSerializer.Serialize(logs);
        byte[] encrypted = Encryptor.Encrypt(json);
        File.WriteAllBytes(path, encrypted);
    }

    public static List<ActivityLog> LoadEncryptedLog(string path)
    {
        if (!File.Exists(path)) return new();
        byte[] encrypted = File.ReadAllBytes(path);
        string decrypted = Encryptor.Decrypt(encrypted);
        return JsonSerializer.Deserialize<List<ActivityLog>>(decrypted) ?? new();
    }

    public static void SaveSummaryJson(DailySummaryResult summary, string reportDir)
    {
        string path = Path.Combine(reportDir, $"summary_{summary.Date:yyyyMMdd}.json");
        File.WriteAllText(path, JsonSerializer.Serialize(summary));
    }

    public static void GenerateHtmlReport(DailySummaryResult summary, List<ActivityLog> logs, string reportDir)
    {
        try
        {
            HtmlBuilder.GenerateReport(summary, logs);
        }
        catch (IOException ex)
        {
            File.AppendAllText("error_log.txt", $"{DateTime.Now}: HTML write failed → {ex.Message}\n");
        }
    }

    public static string GenerateExcelReport(string reportDir, bool enableExcel)
    {
        string excelPath = Path.Combine(reportDir, $"ConsolidatedReport_{DateTime.Now:yyyyMMdd}.xlsx");

        if (enableExcel)
        {
            List<EDailySummaryResult> summaries = SummaryLoader.LoadAllSummaries(reportDir);
            return ExcelReportBuilder.BuildConsolidatedReport(summaries, reportDir);
        }

        if (!File.Exists(excelPath))
            File.WriteAllText(excelPath, "Excel report was skipped today.");

        return excelPath;
    }
}
